const filter = (arr, key, val) => {

};

export default filter;